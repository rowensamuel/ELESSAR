/**
 * Search Controller with Database-First Lookup & On-Demand Scraping
 */

const dashboardService = require("../services/dashboard.service");
const scraperService = require("../../services/scraper.service");
const dataService = require("../../services/data.service");
const { sendSuccess, sendError } = require("../utils/response");
const engine = require("../../lib/engine");
const config = require("../../config");
const FareObservation = require("../../models/FareObservation");
const { isDbConnected } = require("../../config/database");

/**
 * Helper: Fetch all fare observations for a given route from MongoDB.
 * Returns the full observation documents (lean), sorted newest-first.
 */
async function fetchAllObservationsForRoute(route) {
  if (!isDbConnected()) return [];
  try {
    return await FareObservation.find({ route })
      .sort({ scrapedAt: -1 })
      .lean();
  } catch (err) {
    console.warn(`[SEARCH] Failed to fetch observations for ${route}: ${err.message}`);
    return [];
  }
}

/**
 * Helper: Build a price comparison summary from a set of observations,
 * grouping them by their `source` field (e.g. "Air India", "SpiceJet").
 */
function buildPriceComparisonFromObservations(observations) {
  if (!observations || observations.length === 0) return null;

  const bySource = {};
  for (const obs of observations) {
    const src = obs.source || obs.airline || "Unknown";
    if (!bySource[src]) bySource[src] = [];
    const fare = Number(obs.totalFare || obs.fare);
    if (!Number.isNaN(fare) && Number.isFinite(fare) && fare > 0) {
      bySource[src].push(fare);
    }
  }

  // Only generate comparison if we have more than one source
  const providers = {};
  for (const [src, fares] of Object.entries(bySource)) {
    fares.sort((a, b) => a - b);
    providers[src] = {
      status: "ok",
      observationsCount: fares.length,
      minFare: fares.length > 0 ? fares[0] : null,
      maxFare: fares.length > 0 ? fares[fares.length - 1] : null,
      medianFare: fares.length > 0 ? fares[Math.floor(fares.length / 2)] : null,
      meanFare: fares.length > 0 ? Number((fares.reduce((a, b) => a + b, 0) / fares.length).toFixed(2)) : null
    };
  }

  const cheapestEntry = Object.entries(providers)
    .filter(([, v]) => v.minFare !== null)
    .sort(([, a], [, b]) => a.minFare - b.minFare)[0];

  return {
    providers,
    cheapest: cheapestEntry ? cheapestEntry[0] : null,
    comparedAt: new Date().toISOString()
  };
}

/**
 * Core Helper: Process fare observations through the Route Index Engine (lib/engine.js)
 * Computes median representative fare, base fare, route index, weights, and national index contribution.
 */
async function runRouteIndexEngine(canonicalRoute, observations) {
  if (!canonicalRoute) return null;

  // 1. Extract valid fare values
  const fares = (observations || [])
    .map((o) => Number(o.totalFare !== undefined ? o.totalFare : o.fare || o.price))
    .filter((f) => !Number.isNaN(f) && Number.isFinite(f) && f > 0);

  // 2. Compute current representative fare via engine
  const currentFare = engine.getCurrentRepresentativeFare(fares);

  // 3. Load historical fares & DGCA traffic for base calculation
  let historicalFaresMap = {};
  let dgcaVolumesMap = {};
  try {
    historicalFaresMap = await dataService.getHistoricalFares();
    const refYear = await dataService.getLatestReferenceYear();
    dgcaVolumesMap = await dataService.getRouteTraffic(refYear);
  } catch (e) {
    historicalFaresMap = engine.loadHistoricalData(config.paths.historicalFares);
    const dgcaRecords = engine.loadDGCAData(config.paths.dgcaCity);
    dgcaVolumesMap = engine.aggregateRoutePassengerVolume(
      dgcaRecords,
      engine.loadAirportMap(config.paths.airportMap),
      2026
    );
  }

  // 4. Compute base representative fare via dataService from HistoricalFare collection
  const baseResult = await dataService.getBaseFareForRoute(canonicalRoute, currentFare);
  const baseFare = baseResult.baseFare || currentFare;

  // 5. Compute Route Airfare Index via engine: (Current / Base) * 100
  const routeIndex = engine.calculateRouteIndex(currentFare, baseFare);

  // 6. Compute passenger volume & weight via engine
  const volume = dgcaVolumesMap[canonicalRoute] || 0;
  const weightedBasket = engine.calculateRouteWeights(dgcaVolumesMap, config.basketSize);
  const routeWeightObj = weightedBasket.find((w) => w.route === canonicalRoute);
  const weight = routeWeightObj ? routeWeightObj.weight : 0;
  const contribution = routeIndex && weight ? routeIndex * weight : 0;

  // 7. Calculate overall Master Index via engine
  let nationalIndex = null;
  try {
    const masterData = dashboardService.getMasterData();
    nationalIndex = masterData.computedIndex.indiaAirfareIndex;
  } catch (e) {
    nationalIndex = 100;
  }

  // 8. Calculate summary statistics (median, mean, min, max)
  const sorted = [...fares].sort((a, b) => a - b);
  const minFare = sorted.length > 0 ? sorted[0] : null;
  const maxFare = sorted.length > 0 ? sorted[sorted.length - 1] : null;
  const sumFares = sorted.reduce((a, b) => a + b, 0);
  const meanFare = sorted.length > 0 ? Number((sumFares / sorted.length).toFixed(2)) : null;

  return {
    engineStatus: "COMPUTED_VIA_INDEX_ENGINE",
    methodology: "CPI-Augmented Airfare Index (Laspeyres formula with median representative fare)",
    route: canonicalRoute,
    routeIndex: routeIndex ? Number(routeIndex.toFixed(4)) : 100,
    currentRepresentativeFare: currentFare ? Number(currentFare.toFixed(2)) : null,
    baseRepresentativeFare: baseFare ? Number(baseFare.toFixed(2)) : null,
    baseSource: baseResult.baseSource,
    isBaselineEstablished: baseResult.isBaselineEstablished,
    weight: Number(weight.toFixed(6)),
    contribution: Number(contribution.toFixed(4)),
    passengerVolume: volume,
    nationalIndex,
    basePeriod: config.basePeriod,
    fareStats: {
      observationsCount: (observations || []).length,
      validObservationsCount: fares.length,
      medianFare: currentFare ? Number(currentFare.toFixed(2)) : null,
      meanFare,
      minFare,
      maxFare
    }
  };
}

/**
 * GET /api/search?q=...&departureDate=YYYY-MM-DD
 * Searches MongoDB first; triggers on-demand Puppeteer scraping if route data is missing/stale.
 * Processes observations through the Route Index Engine and returns calculated metrics alongside observations.
 */
async function search(req, res) {
  try {
    const query = req.query.q || req.query.query || "";
    const departureDate = req.query.departureDate || new Date();
    const days = parseInt(req.query.days || 30, 10);

    // Direct origin / destination parameters support
    const directOrigin = (req.query.origin || "").trim().toUpperCase();
    const directDest = (req.query.destination || "").trim().toUpperCase();

    if (!query && (!directOrigin || !directDest)) {
      return res.status(200).json({
        success: true,
        query: "",
        data: {
          source: "database",
          scraped: false,
          state: "DATABASE_FRESH",
          routeIndexEngine: null,
          results: [],
          observations: []
        }
      });
    }

    let cleanQuery = query ? query.trim() : `${directOrigin}-${directDest}`;
    let detectedSource = req.query.source;

    // Detect airline keywords in query string
    if (/spicejet|spice\s*jet|\bsg\b/i.test(cleanQuery)) {
      detectedSource = "SpiceJet";
      cleanQuery = cleanQuery.replace(/spicejet|spice\s*jet|\bsg\b/gi, "").trim();
    } else if (/indigo|\b6e\b/i.test(cleanQuery)) {
      detectedSource = "IndiGo";
      cleanQuery = cleanQuery.replace(/indigo|\b6e\b/gi, "").trim();
    } else if (/air\s*india|\bai\b/i.test(cleanQuery)) {
      detectedSource = "Air India";
      cleanQuery = cleanQuery.replace(/air\s*india|\bai\b/gi, "").trim();
    }

    const source = detectedSource || req.query.source || "Air India";
    console.log(`[SEARCH] Query: "${cleanQuery}" (source: ${source})`);

    // 1. Resolve potential route candidates (e.g. "BOM-DEL", "BOM DEL", "Mumbai Delhi", "DEL-GOI")
    const { codeToCity, cityToCode } = dashboardService.getAirportLookups();
    let routeOrigin = null;
    let routeDest = null;
    let canonicalRoute = null;

    if (directOrigin && directDest) {
      routeOrigin = directOrigin;
      routeDest = directDest;
      canonicalRoute = engine.createRouteId(directOrigin, directDest);
    } else if (cleanQuery.includes("-") || cleanQuery.includes(" ") || cleanQuery.includes("→") || cleanQuery.includes("to")) {
      const parts = cleanQuery
        .replace(/→|to/gi, "-")
        .replace(/\s+/g, "-")
        .split("-")
        .map((s) => s.trim())
        .filter(Boolean);

      if (parts.length === 2) {
        const p1 = parts[0].toUpperCase();
        const p2 = parts[1].toUpperCase();

        const code1 = codeToCity[p1] ? p1 : cityToCode[p1] || (p1.length === 3 && /^[A-Z]{3}$/.test(p1) ? p1 : null);
        const code2 = codeToCity[p2] ? p2 : cityToCode[p2] || (p2.length === 3 && /^[A-Z]{3}$/.test(p2) ? p2 : null);

        if (code1 && code2) {
          routeOrigin = code1;
          routeDest = code2;
          canonicalRoute = engine.createRouteId(code1, code2);
        }
      }
    }

    const maxAgeMinutes = parseInt(process.env.SEARCH_DATA_MAX_AGE_MINUTES, 10) || 60;
    const isSearchScrapeEnabled = process.env.SEARCH_SCRAPE_ENABLED !== "false";

    // 2. If a specific route was searched, check freshness in MongoDB
    if (canonicalRoute) {
      console.log(`[SEARCH] Checking MongoDB for route: ${canonicalRoute}`);
      const obsStatus = await dataService.getRouteObservationsStatus(canonicalRoute, maxAgeMinutes);

      if (obsStatus.isFresh && obsStatus.observations.length > 0) {
        console.log(`[SEARCH] Fresh data found in MongoDB for ${canonicalRoute} (${obsStatus.observations.length} obs)`);
        const searchResults = dashboardService.search(cleanQuery);

        // Run observations through the Route Index Engine
        const routeIndexEngine = await runRouteIndexEngine(canonicalRoute, obsStatus.observations);

        // Build price comparison from existing observations grouped by source
        const priceComparison = buildPriceComparisonFromObservations(obsStatus.observations);

        return res.status(200).json({
          success: true,
          query: cleanQuery,
          data: {
            source: "database",
            scraped: false,
            state: "DATABASE_FRESH",
            route: canonicalRoute,
            observationsCount: obsStatus.observations.length,
            latestScrapedAt: obsStatus.latestScrapedAt,
            priceComparison,
            routeIndexEngine,
            results: searchResults,
            observations: obsStatus.observations
          }
        });
      }

      // If missing or stale, trigger on-demand scraping
      if (isSearchScrapeEnabled) {
        console.log(`[SEARCH] No fresh data for ${canonicalRoute}. Starting on-demand scrape...`);
        try {
          // Determine whether to run multi-provider or single-provider scrape
          const isMultiProvider = !detectedSource || detectedSource === "all" || detectedSource === "both";

          let allObservations = [];
          let providerComparison = null;

          if (isMultiProvider) {
            // ── Multi-Provider: scrape Air India + SpiceJet in parallel ──
            const mpResult = await scraperService.scrapeRouteAllProviders(
              routeOrigin,
              routeDest,
              departureDate,
              days
            );

            allObservations = mpResult.allObservations;

            // Build price comparison summary
            const providerEntries = Object.entries(mpResult.providers);
            const cheapestEntry = providerEntries
              .filter(([, v]) => v.minFare !== null)
              .sort(([, a], [, b]) => a.minFare - b.minFare)[0];

            providerComparison = {
              providers: mpResult.providers,
              cheapest: cheapestEntry ? cheapestEntry[0] : null,
              comparedAt: new Date().toISOString()
            };

            // Strip raw observations from the per-provider block to keep response lean
            for (const key of Object.keys(providerComparison.providers)) {
              delete providerComparison.providers[key].observations;
            }
          } else {
            // ── Single-Provider: respect the user's explicit airline choice ──
            const freshObs = await scraperService.scrapeRoute(
              source,
              routeOrigin,
              routeDest,
              departureDate,
              days
            );
            allObservations = freshObs;
          }

          console.log(`[SEARCH] On-demand scrape completed. ${allObservations.length} observations saved.`);

          // Invalidate cache and recalculate master index via engine
          dashboardService.invalidateCache();
          await dataService.recalculateMasterIndex();
          const freshResults = dashboardService.search(cleanQuery);

          // Fetch ALL observations for this route from DB (includes freshly scraped + older ones)
          const dbObs = await fetchAllObservationsForRoute(canonicalRoute);

          // Run all observations through the Route Index Engine
          const routeIndexEngine = await runRouteIndexEngine(canonicalRoute, dbObs);

          return res.status(200).json({
            success: true,
            query: cleanQuery,
            data: {
              source: isMultiProvider ? "multi_provider_scrape" : "fresh_scrape",
              scraped: true,
              calculated: true,
              state: "SCRAPED",
              route: canonicalRoute,
              scrapedAt: new Date().toISOString(),
              observationsCount: dbObs.length,
              ...(providerComparison && { priceComparison: providerComparison }),
              routeIndexEngine,
              results: freshResults,
              observations: dbObs
            }
          });

        } catch (scrapeErr) {
          console.warn(`[SEARCH] On-demand scrape notice for ${canonicalRoute}: ${scrapeErr.message}`);
          // If scraper failed, fall back to existing database results if any exist
          const existingResults = dashboardService.search(cleanQuery);
          const existingObs = await fetchAllObservationsForRoute(canonicalRoute);
          const routeIndexEngine = await runRouteIndexEngine(canonicalRoute, existingObs);

          return res.status(200).json({
            success: true,
            query: cleanQuery,
            data: {
              source: "database",
              scraped: false,
              state: "SCRAPE_FAILED",
              error: scrapeErr.message,
              route: canonicalRoute,
              observationsCount: existingObs.length,
              routeIndexEngine,
              results: existingResults,
              observations: existingObs
            }
          });
        }
      }

      // Scraping disabled — still return all existing DB observations and process through engine
      const dbObs = await fetchAllObservationsForRoute(canonicalRoute);
      const searchResults = dashboardService.search(cleanQuery);
      const routeIndexEngine = await runRouteIndexEngine(canonicalRoute, dbObs);

      return res.status(200).json({
        success: true,
        query: cleanQuery,
        data: {
          source: "database",
          scraped: false,
          state: obsStatus.observations.length > 0 ? "DATABASE_STALE" : "NO_DATA",
          route: canonicalRoute,
          observationsCount: dbObs.length,
          latestScrapedAt: obsStatus.latestScrapedAt,
          routeIndexEngine,
          results: searchResults,
          observations: dbObs
        }
      });
    }

    // 3. General Search (City, Airport, Airline, or partial matches)
    const results = dashboardService.search(cleanQuery);

    // For general searches, try to collect observations across all matched routes and process through engine
    let allObservations = [];
    let routeIndexEngine = null;

    if (isDbConnected() && results && results.length > 0) {
      const matchedRoutes = results
        .map((r) => r.route || r.routeId || null)
        .filter(Boolean);
      const uniqueRoutes = [...new Set(matchedRoutes)];

      if (uniqueRoutes.length > 0) {
        try {
          allObservations = await FareObservation.find({ route: { $in: uniqueRoutes } })
            .sort({ scrapedAt: -1 })
            .lean();

          // Process the primary matched route through the engine
          routeIndexEngine = await runRouteIndexEngine(uniqueRoutes[0], allObservations.filter(o => o.route === uniqueRoutes[0]));
        } catch (err) {
          console.warn(`[SEARCH] Failed to fetch observations for general search: ${err.message}`);
        }
      }
    }

    return res.status(200).json({
      success: true,
      query: cleanQuery,
      data: {
        source: "database",
        scraped: false,
        state: "DATABASE_FRESH",
        observationsCount: allObservations.length,
        routeIndexEngine,
        results,
        observations: allObservations
      }
    });

  } catch (err) {
    return sendError(res, "SEARCH_FAILED", err.message, 500);
  }
}

module.exports = {
  search
};


