/**
 * Currency Parsing Utility for Indian Rupee formats
 */

/**
 * Parses Indian currency strings into clean numbers.
 * Handles formats like:
 *  - "₹6,412" -> 6412
 *  - "₹12,500" -> 12500
 *  - "₹1,05,000" -> 105000
 *  - "6412" -> 6412
 *  - 6412 -> 6412
 * 
 * @param {string|number} rawValue 
 * @returns {number|null} Parsed numeric amount or null if invalid
 */
function parseIndianCurrency(rawValue) {
  if (rawValue === null || rawValue === undefined) {
    return null;
  }

  if (typeof rawValue === "number") {
    return Number.isFinite(rawValue) && rawValue > 0 ? rawValue : null;
  }

  const str = String(rawValue).trim();
  if (!str) return null;

  // Remove currency symbols (₹, INR, Rs., etc.), commas, spaces, and formatting characters
  const cleanStr = str.replace(/[₹\s,INRRs.]/gi, "");
  const num = parseFloat(cleanStr);

  if (Number.isNaN(num) || !Number.isFinite(num) || num <= 0) {
    return null;
  }

  return Math.round(num);
}

module.exports = {
  parseIndianCurrency
};
