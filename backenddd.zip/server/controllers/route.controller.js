/**
 * Route Controller
 */

const dashboardService = require("../services/dashboard.service");
const { sendSuccess, sendError } = require("../utils/response");

/**
 * GET /api/routes
 * Supports ?limit, ?sort, ?search
 */
function getRoutes(req, res) {
  try {
    const { limit, sort, search } = req.query;
    const data = dashboardService.getRoutes({ limit, sort, search });
    return sendSuccess(res, data);
  } catch (err) {
    return sendError(res, "ROUTES_FETCH_FAILED", err.message, 500);
  }
}

/**
 * GET /api/routes/:route
 * Detailed inspection of a specific route pair.
 */
function getRouteById(req, res) {
  try {
    const routeId = req.params.route;
    const data = dashboardService.getRouteDetail(routeId);

    if (!data) {
      return sendError(
        res,
        "ROUTE_NOT_FOUND",
        `Route ${routeId} was not found.`,
        404
      );
    }

    return sendSuccess(res, data);
  } catch (err) {
    return sendError(res, "ROUTE_FETCH_FAILED", err.message, 500);
  }
}

/**
 * GET /api/routes/:route/history
 * Timestamped fare history for a specific route.
 */
function getRouteHistory(req, res) {
  try {
    const routeId = req.params.route;
    const period = req.query.period || "30d";
    const history = dashboardService.getRouteHistory(routeId, period);

    if (!history) {
      return sendError(
        res,
        "ROUTE_NOT_FOUND",
        `Route ${routeId} was not found.`,
        404
      );
    }

    if (!history.available) {
      return sendError(
        res,
        "ROUTE_HISTORY_NOT_AVAILABLE",
        `Historical fare observations for route ${routeId} are not available.`,
        404
      );
    }

    return sendSuccess(res, {
      route: history.route,
      period: history.period,
      points: history.points
    });
  } catch (err) {
    return sendError(res, "ROUTE_HISTORY_FAILED", err.message, 500);
  }
}

module.exports = {
  getRoutes,
  getRouteById,
  getRouteHistory
};
